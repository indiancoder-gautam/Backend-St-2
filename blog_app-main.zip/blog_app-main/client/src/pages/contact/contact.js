import React from 'react'
import "./contact.css"

export default function Contact() {
  return (
    <div className='contact'>Contact</div>
  )
}
